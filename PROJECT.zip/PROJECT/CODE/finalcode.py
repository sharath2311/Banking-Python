from Tkinter import *
import Tkinter
import tkMessageBox
import time
import MySQLdb
from random import *
from datetime import datetime
from datetime import date
from Carbon.AppleEvents import type128BitFloatingPoint
db = MySQLdb.connect(host="localhost",    # your host, usually localhost
                     user="root",         # your username
                     passwd="sharath123",  # your password
                     db="sharath") 
cur=db.cursor(); 


root=Tk()
Mainmenu = Frame(root, bg="green")
def Signin():

    global Login,UserName,UPass
    root.iconify()
    Login=Toplevel(root)
    logpage = Label(Login, text="Log in",bg="purple",fg="orange")
    logpage.pack()

    #Login.pack(anchor=N, fill=BOTH, expand=True, side=LEFT)
    name=Label(Login,text="CUSTOMER ID",fg="black")
    password=Label(Login,text="PASSWORD",fg="black")
    Epass=StringVar()
    UserName=Entry(Login)

    UPass=Entry(Login,show='*')
    print(UPass.get())
    name.pack()
    UserName.pack()
    password.pack()
    UPass.pack()
    logme=Button(Login,text="LOGIN",bg="yellow",command=sgn)
    logme.pack()
    Login.mainloop()
    
def Newuser():
    global SignUp,fname1,lname2,Nadd,Npass,Ntype,capital1,acctype
    root.iconify()
    SignUp = Toplevel(root)

    Fname = Label(SignUp, text="FIRSTNAME")
    Fname.grid(row=0, sticky=E)
    fname1 = Entry(SignUp)
    fname1.grid(row=0, column=1)

    Lname = Label(SignUp, text="LASTNAME")
    Lname.grid(row=1, sticky=E)
    lname2 = Entry(SignUp)
    lname2.grid(row=1, column=1)

    address = Label(SignUp, text="ADDRESS ")
    address.grid(row=2, sticky=E)
    Nadd= Entry(SignUp)
    Nadd.grid(row=2, column=1)

    PASS = Label(SignUp, text="PASSWORD")
    PASS.grid(row=3, sticky=E)
    Npass=Entry(SignUp)
    Npass.grid(row=3,column=1)
    Label(SignUp,text="ACC.TYPE").grid(row=4,column=0,sticky=E)
    acctype=StringVar()
    Ntype=Spinbox(SignUp,textvariable=acctype)
    Ntype.grid(row=4,column=1)
    Ntype.config(values=('SA','CA'))

    Label(SignUp, text="CAPITAL").grid(row=5, column=0, sticky=E)
    global Namt
    Namt=DoubleVar()
    capital1 = Spinbox(SignUp,textvariable=Namt)
    capital1.grid(row=5,column=1)
    capital1.config(values=(0.0, 500.0,1000.0,1500.0,2000.0,2500.0,3000.0))
    b1 = Button(SignUp, text="submit",fg="orange",bg="brown",command=AddUser)
    b1.grid(row=6,column=2)

    
   


def AddUser():
    fname=fname1.get()
    lname=lname2.get()
    name="%s %s" %(fname,lname)
    add=Nadd.get()
    isP=checkNewPass()
    checkAccount()
    #if isP:
        #if Nbal!=-1:   
    id1 = "%s%d" % ('CID', randint(1, 200))
    id2 = "%s%d" % ('ACCN', randint(200, 400))
    cur.execute("INSERT INTO sharath.customer(cus_id,acc_no,name,address,type,balance,password) VALUES(('%s'),('%s'),('%s'),('%s'),('%s'),('%d'),('%s'))" % (id1, id2, name, add, type1, Nbal, pass1))
    db.commit()
    tkMessageBox.showinfo(title="YOUR USER ID", message = id1)
    tkMessageBox.showinfo(title="YOUR ACCOUNT NO", message=id2)
    tkMessageBox.showinfo(title="CONGRATS!",message="ACCOUNT IS SUCCESSFULLY CREATED ")
def Admin():
    global LoginAd
    root.iconify()
    LoginAd = Toplevel(root)
    logpage = Label(LoginAd, text=" AdminLog in", bg="purple", fg="orange")
    logpage.pack()

    # Login.pack(anchor=N, fill=BOTH, expand=True, side=LEFT)
    name = Label(LoginAd, text="ADMINID", fg="black")
    password = Label(LoginAd, text="PASSWORD", fg="black")
    e1 = Entry(LoginAd)
    e2 = Entry(LoginAd)

    name.pack()
    e1.pack()
    ###%%%global adminname
    ###%%%adminname=e1.get()
    password.pack()
    e2.pack()
    ###%%%global adminPass
    ###%%%adminPass=e2.get()
    logme = Button(LoginAd, text="LOGIN", bg="yellow",command=AdminOP)
    logme.pack()
    #LoginAD.mainloop()
def AdminOP():
    LoginAd.destroy()
    global OptionAd
    OptionAd=Toplevel(root)
    history=Label(OptionAd,text="PRINT CLOSURE HISTORY",bg="red",fg="white")
    history.grid(row=0)
    b1 = Button(OptionAd, text="submit", command=ChangeAddress)
    b1.grid(row=0, column=20)
    logout = Button(OptionAd, text="LOGOUT", command=OptionAd.destroy, bg="green", fg="gold")
    logout.grid(row=1, column=100)

def MenuFrame():

    global Mainmenu
    Mainmenu.pack(anchor=N, fill=BOTH, expand=True, side=LEFT )

    BankName=Label(Mainmenu,text="THE GLOBAL BANK",font = "Verdana 20 bold",fg="white",bg="blue",justify=CENTER)
    BankName.pack(fill=X)

    '''Existing =Label(Mainmenu)
    Existing.pack(fill=BOTH)
    Existing.img=PhotoImage(file="C:/Users/solai/Desktop/6ce0b9f297a42afc2a5211e04711b17f.gif")
    Existing.config(image=Existing.img)'''
    Quit=Button(Mainmenu,text="QUIT",bg="white",fg="red",command=Mainmenu.quit)
    Quit.pack(anchor=SE,side=BOTTOM)

    signin=Button(Mainmenu,text="SIGNIN",fg="blue",bg="white",width=10,command =Signin)


    signin.place(x=0,y=80)

    signup = Button(Mainmenu, text="SIGNUP", fg="blue", bg="white", width=10,command=Newuser)
    signup.place(x=0,y=120)

    admin = Button(Mainmenu, text="Admin", fg="blue", bg="white", width=10,command=Admin)
    admin.place(x=0, y=160)
    Mainmenu.mainloop()



def ChangeAddress():
    add=add1.get()
    #print add
    cur.execute("UPDATE CUSTOMER set address='"+ add+"' where cus_id='"+ cid+"'")
    db.commit()
def Transferto():
    acc2=tracc.get()
    acc=r[1]
    ammount=tamt.get()
    p="%s %s %s %s" %('Tranfer',ammount,'to',acc2)
    cur.execute("SELECT balance,type FROM CUSTOMER WHERE acc_no='"+ acc+"' and balance>='"+ ammount+"'")
    db.commit()
    res=cur.fetchall()
    if res:
        for rup in res:
            ty=rup[1]
            am=str(rup[0]-int(ammount))
        if (ty=='CA' and am>=5000) or ty!='CA':
            cur.execute("UPDATE CUSTOMER SET balance=balance-'"+ ammount+"' where acc_no='"+ acc+"' and balance>'"+ ammount+"'" )
            cur.execute("INSERT INTO sharath.record(cid,acc_no,activity_date,deposit_amt,ammt) VALUES(('%s'),('%s'),NOW(),('%s'),('%s'))" %(cid,acc,p,am))
            print("Withdrawal successful")
            db.commit()
            cur.execute("SELECT balance,cus_id FROM CUSTOMER WHERE acc_no='"+ acc2+"' and balance>='"+ ammount+"' or balance<'"+ ammount+"'")
            db.commit()
            res=cur.fetchall()
            p="%s %s %s %s" %('deposit',ammount,'by',acc)
            for rup in res:
                cur.execute("INSERT INTO sharath.record(cid,acc_no,activity_date,deposit_amt,ammt) VALUES(('%s'),('%s'),NOW(),('%s'),('%s'))" %(rup[1],acc2,p,str(rup[0]+int(ammount))))
                break
            cur.execute("UPDATE CUSTOMER SET balance=balance+'"+ ammount+"' where acc_no='"+ acc2+"'")
            print("Deposit successful")
            db.commit()
        else:
            print("min balance is not sufficient")
    else:
        print("insufficient amount..")
        print("Transaction failed")
    

def Transfermoney():
    Option.iconify()
    global tracc
    global tamt
    trans=Toplevel(root)
    trans.title("TRANSACTION")

    to=Label(trans,text="TO")
    to.grid(row=0,stick=E)
    tracc=Entry(trans)
    tracc.grid(row=0,column=1)
    ###%%%global tranferto
    ###%%%transferto=e1.get()

    amt = Label(trans, text="AMOUNT")
    amt.grid(row=1, stick=E)
    tamt = Entry(trans)
    tamt.grid(row=1, column=1)
    ###%%%global amttotranfer
    ###%%%amttotranfer.get()

    b1=Button(trans,text="PROCEED",bg="green",fg="white",command=Transferto)
    b1.grid(row=2,column=2)

def Withdraw():
    acc=r[1]
    ammount=withdraw1.get()
    p="%s %s" %('Withdrawal',ammount)
    cur.execute("SELECT balance,type FROM CUSTOMER WHERE acc_no='"+ acc+"' and balance>='"+ ammount+"'")
    db.commit()
    res=cur.fetchall()
    if res:
        for rup in res:
            ty=rup[1]
            am=str(rup[0]-int(ammount))
        if (ty=='CA' and am>=5000) or ty!='CA':
            cur.execute("UPDATE CUSTOMER SET balance=balance-'"+ ammount+"' where acc_no='"+ acc+"' and balance>'"+ ammount+"'" )
            cur.execute("INSERT INTO sharath.record(cid,acc_no,activity_date,deposit_amt,ammt) VALUES(('%s'),('%s'),NOW(),('%s'),('%s'))" %(cid,acc,p,am))
            db.commit()
        else:
            print("min balance is not sufficient")
    else:
        print("insufficient amount..")
def Deposit():
    acc=r[1]
    ammount=dep1.get()
    p="%s %s" %('deposit',ammount)
    cur.execute("SELECT balance FROM CUSTOMER WHERE acc_no='"+ acc+"'")
    db.commit()
    res=cur.fetchall()
    for rup in res:
        amt=str(rup[0]+int(ammount))
        #cur.execute('INSERT INTO RECORD VALUES(:1,:2,:3,:4,:5)'%(cid,acc,today,p,r[0]+ammount))
        cur.execute("INSERT INTO sharath.record(cid,acc_no,activity_date,deposit_amt,ammt) VALUES(('%s'),('%s'),NOW(),('%s'),('%s'))" %(cid,acc,p,amt))
        break
    cur.execute("UPDATE CUSTOMER SET balance=balance+'"+ ammount+"' where acc_no='"+ acc+"'") 
    db.commit()
def Print():
    print("the bill is prrinted")
def Closure():
    acc=r[1]
    cur.execute("SELECT cus_id,acc_no,balance,address FROM CUSTOMER WHERE acc_no='"+ acc+"' AND password='"+ p+"'")
    db.commit()
    res=cur.fetchall()
    for rup in res:
        #print r
        cur.execute("INSERT INTO sharath.history(cu_id,ac_no,balanc,dat_tim,addr) VALUES(('%s'),('%s'),('%d'),NOW(),('%s'))" %(str(rup[0]),str(rup[1]),rup[2],str(rup[3])))
        db.commit()
        break
    cur.execute("DELETE from sharath.customer WHERE acc_no='"+ acc+"' and password='"+ p+"'")
    db.commit()
    
def checkNewPass():  
    global pass1     
    pass1=Npass.get()
    t=len(pass1)
    if(t>=8):           
        return 1
    else:       
        return 0

def checkAccount():
    
    global Nbal
    global type1
    Nbal=-1
    type1=acctype.get()
    cap=Namt.get()
    if type1=="SA" :
        Nbal=0+int(cap)
    if type1=='CA':
        Nbal=5000+int(cap)
    
    print type1
    print Nbal
    print cap
       

def sgn():
    global r
    global acc
    global cid
    global p
    i = 1
    list1 = []
    cid = UserName.get()
    p = UPass.get()
    cur.execute("SELECT * from CUSTOMER WHERE cus_id='" + cid + "' and password='" + p + "'")
    res = cur.fetchall()
    db.commit()
    if res:
        for r in res:
            #mul = "%d %s %s" % (i, '.', r[1])
            list1.append(r[1])
            Login.iconify()
            global Option, add1, dep1, withdraw1
            Option = Toplevel(root)
            Option.title("USER'S CORNER")
            add = Label(Option, text="ADDRESS CHANGE")
            add.grid(row=0, sticky=E)
            add1 = Entry(Option)
            add1.grid(row=0, column=1)
            dep = Label(Option, text="DEPOSIT")
            dep.grid(row=1, sticky=E)
            dep1 = Entry(Option)
            dep1.grid(row=1, column=1)
            withdraw = Label(Option, text="WITHDRAW")
            withdraw.grid(row=2, sticky=E)
            withdraw1 = Entry(Option)
            withdraw1.grid(row=2, column=1)
            b1 = Button(Option, text="submit", command=ChangeAddress)
            b1.grid(row=0, column=2)
            b2 = Button(Option, text="submit", command=Deposit)
            b2.grid(row=1, column=2)
            b3 = Button(Option, text="submit", command=Withdraw)
            b3.grid(row=2, column=2)
            # p\rintstatement=Label(row=3,sticky=E)
            printstatement = Button(Option, text="PRINT", bg="purple", fg="white", command=Print)
            printstatement.grid(row=3, columnspan=2, sticky=S)
            transfer = Button(Option, text="TRANSFER", bg="blue", command=Transfermoney)
            transfer.grid(row=4, columnspan=2, sticky=S)
            closure = Button(Option, text="CLOSURE", bg="grey", fg="black", command=Closure)
            closure.grid(row=5, columnspan=2, sticky=S)
            logout = Button(Option, text="LOGOUT", command=Option.destroy, bg="green", fg="gold")
            logout.grid(row=6, column=1)
    else:
        tkMessageBox.showinfo("Sorry!" ,"Invalid password/username")
MenuFrame()

    
